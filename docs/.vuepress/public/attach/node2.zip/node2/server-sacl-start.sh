#!/bin/bash
ROOT=`dirname $0`
export KAFKA_OPTS=" -Djava.security.auth.login.config=kafka_server_jaas.conf"
../kafka_2.11-2.0.0/bin/kafka-server-start.sh serverAcl.properties >> kafka.log 2>&1 &
