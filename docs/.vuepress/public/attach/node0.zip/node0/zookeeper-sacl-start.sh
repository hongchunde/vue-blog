#!/bin/bash

export KAFKA_OPTS=" -Djava.security.auth.login.config=kafka_zoo_jaas.conf -Dzookeeper.sasl.serverconfig=ZKServer "
../kafka_2.11-2.0.0/bin/zookeeper-server-start.sh zookeeperAcl.properties >> zookeeper.log 2>&1 &

